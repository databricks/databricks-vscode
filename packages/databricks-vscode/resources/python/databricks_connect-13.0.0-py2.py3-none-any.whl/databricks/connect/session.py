#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2020-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import logging
import os
from typing import Any, Optional

from pyspark.sql.session import SparkSession


# This class can be dropped once support for Python 3.8 is dropped
# In Python 3.9, the @property decorator has been made compatible with the
# @classmethod decorator (https://docs.python.org/3.9/library/functions.html#classmethod)
#
# @classmethod + @property is also affected by a bug in Python's docstring which was backported
class classproperty(property):
    def __get__(self, instance: Any, owner: Any = None) -> "DatabricksSession.Builder":
        # The "type: ignore" below silences the following error from mypy:
        # error: Argument 1 to "classmethod" has incompatible
        # type "Optional[Callable[[Any], Any]]";
        # expected "Callable[..., Any]"  [arg-type]
        return classmethod(self.fget).__get__(None, owner)()  # type: ignore


class DatabricksSession:
    """
    The entry point for Databricks Connect.
    Create a new Pyspark session which connects to a remote Spark cluster and executes specified
    DataFrame APIs.

    Examples
    --------
    >>> spark = DatabricksSession.builder.getOrCreate()
    >>> df = spark.range(10)
    >>> print(df)
    """

    class Builder:
        """
        Builder to construct connection parameters.
        An instance of this class can be created using DatabricksSession.builder.
        """

        def __init__(self):
            self._conn_string: Optional[str] = None
            self._host: Optional[str] = None
            self._cluster_id: Optional[str] = None
            self._token: Optional[str] = None

        def remote(
            self, conn_string=None, *, host=None, cluster_id=None, token=None
        ) -> "DatabricksSession.Builder":
            """
            Specify connection and authentication parameters to connect to the remote Databricks
            cluster. Either the conn_string parameter should be specified, or a combination of the
            host, cluster_id and token parameters, but not both.

            Parameters
            ----------
            conn_string : str, optional
                The full spark connect connection string starting with "sc://".
                See https://github.com/apache/spark/blob/master/connector/connect/docs/client-connection-string.md # noqa: E501
            host : str, optional
                The Databricks workspace URL
            cluster_id: str, optional
                The cluster identifier where the Databricks connect queries should be executed.
            token: str, optional
                The Databricks personal access token used to authenticate into the cluster and on
                whose behalf the queries are executed.

            Returns
            -------
            DatabricksSession.Builder
                The same instance of this class with the values configured.

            Examples
            --------
            Using a simple conn_string
            >>> conn = "sc://foo-workspace.cloud.databricks.com/;token=dapi1234567890;x-databricks-cluster-id=0301-0300-abcdefab" # noqa: E501
            >>> spark = DatabricksSession.builder.remote(conn).getOrCreate()

            Using keyword parameters
            >>> conn = "sc://foo-workspace.cloud.databricks.com/;token=dapi1234567890;x-databricks-cluster-id=0301-0300-abcdefab" # noqa: E501
            >>> spark = DatabricksSession.builder.remote(
            >>>     host="foo-workspace.cloud.databricks.com",
            >>>     token="dapi1234567890",
            >>>     cluster_id="0301-0300-abcdefab"
            >>> ).getOrCreate()
            """
            self._conn_string = conn_string
            self._host = host
            self._cluster_id = cluster_id
            self._token = token
            return self

        def host(self, host: str) -> "DatabricksSession.Builder":
            """
            The Databricks workspace URL.

            Parameters
            ----------
            host: str
                The Databricks workspace URL.

            Returns
            -------
            DatabricksSession.Builder
                The same instance of this class with the host configured.
            """
            self._host = host
            return self

        def clusterId(self, clusterId: str) -> "DatabricksSession.Builder":
            """
            The cluster identifier where the Databricks connect queries should be executed.

            Parameters
            ----------
            clusterId: str
                The cluster identifier where the Databricks connect queries should be executed.

            Returns
            -------
            DatabricksSession.Builder
                The same instance of this class with the clusterId configured.
            """
            self._cluster_id = clusterId
            return self

        def token(self, token: str) -> "DatabricksSession.Builder":
            """
            The Databricks personal access token used to authenticate into the cluster and on whose
            behalf the queries are executed.

            Parameters
            ----------
            token: str
                The Databricks personal access token used to authenticate into the cluster and on
                whose behalf the queries are executed.

            Returns
            -------
            DatabricksSession.Builder
                The same instance of this class with the token configured.
            """
            self._token = token
            return self

        def getOrCreate(self) -> SparkSession:
            """
            Create a new :class:SparkSession that can then be used to execute DataFrame APIs on.

            Returns
            -------
            SparkSession
                A spark session initialized with the provided connection parameters. All DataFrame
                queries to this spark session are executed remotely.
            """
            if self._conn_string is not None:
                if (
                    self._host is not None
                    or self._token is not None
                    or self._cluster_id is not None
                ):
                    # then conn_string should not be specified
                    raise Exception(
                        "Either conn_string or (host, token and clusterId) but not both must be specified."  # noqa: E501
                    )
                logging.debug(f"Using connection string: {self._conn_string}")
                return SparkSession.builder.remote(self._conn_string).getOrCreate()

            if self._host is not None or self._token is not None or self._cluster_id is not None:
                # if any of these values are specified
                if self._host is None or self._token is None or self._cluster_id is None:
                    # then all of them should be specified
                    raise Exception("host, token and clusterId must all be specified.")

                host = self._host.removeprefix("http://").removeprefix("https://")

                conn_string = f"sc://{host}:443/;token={self._token};x-databricks-cluster-id={self._cluster_id}"  # noqa: E501
                logging.debug(f"Using constructed connection string: {conn_string}")
                return SparkSession.builder.remote(conn_string).getOrCreate()

            if "SPARK_REMOTE" not in os.environ:
                raise Exception("No spark connection information is specified.")

            return SparkSession.builder.getOrCreate()

    @classproperty
    def builder(cls) -> "DatabricksSession.Builder":
        """Create a new instance of :class:DatabricksSession.Builder"""
        return cls.Builder()
